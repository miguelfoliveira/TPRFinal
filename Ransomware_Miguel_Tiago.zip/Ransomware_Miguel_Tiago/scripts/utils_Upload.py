from __future__ import print_function
import os

from apiclient.discovery import build
from httplib2 import Http
from oauth2client import file, client, tools
import httplib2

from apiclient import discovery
from oauth2client.file import Storage

SCOPES = 'https://www.googleapis.com/auth/drive'
CLIENT_SECRET_FILE = 'client_secret.json'
APPLICATION_NAME = 'Drive API Quickstart'
	
def insertIntoDataStruct(dic,name,date):
	if not name in dic:
		dic[name] = [date]
	else:
		dic[name] = dic[name] + [date]
		
def get_credentials():
    """Gets valid user credentials from storage.

    If nothing has been stored, or if the stored credentials are invalid,
    the OAuth2 flow is completed to obtain the new credentials.

    Returns:
        Credentials, the obtained credential.
    """
    home_dir = os.path.expanduser('~')
    credential_dir = os.path.join(home_dir, '.credentials')
    if not os.path.exists(credential_dir):
        os.makedirs(credential_dir)
    credential_path = os.path.join(credential_dir,
                                   'drive-quickstart.json')

    store = Storage(credential_path)
    credentials = store.get()
    if not credentials or credentials.invalid:
        flow = client.flow_from_clientsecrets(CLIENT_SECRET_FILE, SCOPES)
        flow.user_agent = APPLICATION_NAME
        if flags:
            credentials = tools.run_flow(flow, store, flags)
        else: # Needed only for compatibility with Python 2.6
            credentials = tools.run(flow, store)
        print('Storing credentials to ' + credential_path)
    return credentials
    
def upload_file(files):
	"""Shows basic usage of the Google Drive API.

	Creates a Google Drive API service object and outputs the names and IDs
	for up to 10 files.
	"""
	credentials = get_credentials()
	http = credentials.authorize(httplib2.Http())
	service = discovery.build('drive', 'v3', http=http)
	files_dict = {}
	
	for filename, mimeType in files:
		metadata = {'name': filename}
		if mimeType:
			metadata['mimeType'] = mimeType
		res = service.files().create(body= metadata, media_body = filename).execute()
		if res:
			print('Uploaded "%s" (%s)' % (filename, res['mimeType']))
			insertIntoDataStruct(files_dict,filename,res.get('id'))
			
	return files_dict,service
	"""		
	if res:
    MIMETYPE = 'application/pdf'
    data = DRIVE.files().export(fileId=res['id'], mimeType =MIMETYPE )
    if data:
        fn = '%s.pdf' % os.path.splitext(filename)[0]
        with open(fn, 'wb') as fh:
            fh.write(data)
        print('Downloaded "%s" (%s)' % (fn, MIMETYPE))"""

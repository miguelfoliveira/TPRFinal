#!/usr/bin/python
import sys
import argparse

from apiclient import errors
from httplib2 import Http
from apiclient.discovery import build
from oauth2client import file, client, tools

from apiclient import discovery
from oauth2client.file import Storage

import utils_Upload as up
import httplib2
import time
import numpy as np

def int_positive(value):
    #ivalue = int(value)
    ivalue = float(value)
    if ivalue < 0:
        raise argparse.ArgumentTypeError("%s is an invalid positive int value" % value)
    return ivalue
    
# Arguments    
parser = argparse.ArgumentParser(description='Deleting files from folder')
parser.add_argument('-s', '--sourcefolder', type=str, help='source folder id', default='0BwcPr38tzpusVjRWcFhvTzBiOTQ')
parser.add_argument('-u', '--user', type=str, help='user that will move files', default='user')
parser.add_argument('-b', '--bottime', help='time that the bot will upload files', type=int_positive, default=1)
args = parser.parse_args() 

def usage():
	print('###############################################################################################################################')
	print('Usage - python deleteFiles.py -s <source_folder_id> -u <user/bot> -b <time to time the bot to delete files>')
	print('###############################################################################################################################')

def printFilesFolder(service, folder_id_source, user, time_bot):
  """Print files belonging to a folder.
  Args:
    service: Drive API service instance.
    folder_id: ID of the folder to print files from.
  """
  page_token = None
  while True:
    try:
      param = {}
      if page_token:
        param['pageToken'] = page_token
      children = service.children().list(folderId=folder_id_source, **param).execute()
      if len(children.get('items', [])) == 0:
		  print('The selected folder contains no files to delete... select another folder!!')
		  print('Usage - python deleteFiles.py -s <source_folder_id> -u <user/bot> -b <time to time the bot to delete files>')
		  sys.exit()
      for child in children.get('items', []):
		delete_file(service, folder_id_source, str(child['id']), user, time_bot)
      page_token = children.get('nextPageToken')
      if not page_token:
        break
    except errors.HttpError, error:
      print 'An error occurred: %s' % error
      usage()
      sys.exit()

def delete_file(service, folder_id, file_id, user, time_bot):
	"""Permanently delete a file, skipping the trash.
	Args:
	service: Drive API service instance.
	file_id: ID of the file to delete.
	"""
	try:
		if user=='user':
			time.sleep(np.random.exponential(scale=10))	
		else:
			time.sleep(time_bot)		
		# delete file	
		service.files().trash(fileId=file_id).execute()
		print('Deleted file "%s" from folder (%s)' % (file_id, folder_id))
	except errors.HttpError, error:
		print 'An error occurred: %s' % error
		usage()
		sys.exit()
    
def main():
	# Usage - python deleteFiles.py -s <source_folder_id> -u <user/bot> -b <time to time the bot to delete files>
	credentials = up.get_credentials()
	http = credentials.authorize(httplib2.Http())
	service = discovery.build('drive', 'v2', http=http)
	
	printFilesFolder(service, args.sourcefolder, args.user, args.bottime)
	print('Deleting files succesfully!!!!!') 
 
if __name__ == '__main__':
    main()

#!/usr/bin/python

from __future__ import print_function
import httplib2
import os
import sys
import argparse

from apiclient import discovery
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage

import datetime
import time
import numpy as np
import matplotlib.pyplot as plt

import utils_Upload as up

from apiclient import errors
from apiclient.http import MediaFileUpload

def int_positive(value):
    #ivalue = int(value)
    ivalue = float(value)
    if ivalue < 0:
        raise argparse.ArgumentTypeError("%s is an invalid positive int value" % value)
    return ivalue
    
# Arguments    
parser = argparse.ArgumentParser(description='Uploading files')
parser.add_argument('-u', '--user', type=str, help='user that will upload files', default='user')
parser.add_argument('-b', '--bottime', help='time that the bot will upload files', type=int_positive, default=1)
parser.add_argument('-t', '--time', help='time range of upload action', type=int_positive, default=1)
args = parser.parse_args()    

# If modifying these scopes, delete your previously saved credentials
# at ~/.credentials/appsactivity-python-quickstart.json
SCOPES = 'https://www.googleapis.com/auth/activity https://www.googleapis.com/auth/drive.metadata.readonly'
CLIENT_SECRET_FILE = 'client_secret.json'
APPLICATION_NAME = 'G Suite Activity API Python Quickstart'

Dict_Writes = {}
Dict_Upload = {}
Dict_NumberWrites = []
dict_up = {}
dict_up_check = {}
dict_ext = {}
'''
files = (
	('hello.txt', None),
	('hello.txt', 'application/vnd.google-apps.document'),)	
	'''
	
files = (('hello.txt', None),)

def get_credentials():
    """Gets valid user credentials from storage.

    If nothing has been stored, or if the stored credentials are invalid,
    the OAuth2 flow is completed to obtain the new credentials.

    Returns:
        Credentials, the obtained credential.
    """
    home_dir = os.path.expanduser('~')
    credential_dir = os.path.join(home_dir, '.credentials')
    if not os.path.exists(credential_dir):
        os.makedirs(credential_dir)
    credential_path = os.path.join(credential_dir, 'appsactivity-python-quickstart.json')

    store = Storage(credential_path)
    credentials = store.get()
    if not credentials or credentials.invalid:
        flow = client.flow_from_clientsecrets(CLIENT_SECRET_FILE, SCOPES)
        flow.user_agent = APPLICATION_NAME
        if flags:
            credentials = tools.run_flow(flow, store, flags)
        else: # Needed only for compatibility with Python 2.6
            credentials = tools.run(flow, store)
        print('Storing credentials to ' + credential_path)
    return credentials

def get_activity():
	credentials = get_credentials()
	http = credentials.authorize(httplib2.Http())
	service = discovery.build('appsactivity', 'v1', http=http)

	results = service.activities().list(source='drive.google.com',groupingStrategy = 'none', drive_ancestorId='root', pageSize=5).execute()

	activities = results.get('activities', [])
	if not activities:
		print('No activity.')
	else:
		print('Recent activity:')
		
	for activity in activities:
		event = activity['combinedEvent']
		user = event.get('user', None)
		target = event.get('target', None)
		
		if user == None or target == None:
			continue
			
		time = datetime.datetime.fromtimestamp(
		int(event['eventTimeMillis'])/1000)		
			
		if event['primaryEventType'] == 'upload':
			up.insertIntoDataStruct(dict_up,target['name'],target['id'])			
		
		print('{0}: {1}, {2}, {3} ({4})'.format(time, user['name'].encode('utf-8'),
				event['primaryEventType'].encode('utf-8'), target['name'].encode('utf-8'), target['mimeType'].encode('utf-8')))
	
		
def main():
	"""Shows basic usage of the G Suite Activity API.
	Creates a G Suite Activity API service object and
	outputs the recent activity in your Google Drive.
	"""
	# usage - python uploadFiles.py -u <user/bot> -b <time that the bot will upload files> -t <time range to upload files>
	
	# definir intervalo de tempo
	endTime = datetime.datetime.now() + datetime.timedelta(minutes=args.time)

	while True:
		if args.user != 'bot': # upload de ficheiros em x segundos variaveis
			print('User uploading files...')
			if datetime.datetime.now() >= endTime:
				break
			time.sleep(np.random.exponential(scale=10))	
			files_dict, SERVICE = up.upload_file(files)
		else: # upload de ficheiros de 1 em 1s - caracteristico de um bot
			print('Bot uploading files...')
			if datetime.datetime.now() >= endTime:
				break
			time.sleep(args.bottime)	
			files_dict, SERVICE = up.upload_file(files)
		
	print('Uploading files succesfully!!')	
	#time.sleep(2)
	#get_activity()

if __name__ == '__main__':
    main()

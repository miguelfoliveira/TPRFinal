#!/usr/bin/python
import sys
import argparse

from apiclient import errors
from httplib2 import Http
from apiclient.discovery import build
from oauth2client import file, client, tools

from apiclient import discovery
from oauth2client.file import Storage

import utils_Upload as up
import httplib2  

def int_positive(value):
    #ivalue = int(value)
    ivalue = float(value)
    if ivalue < 0:
        raise argparse.ArgumentTypeError("%s is an invalid positive int value" % value)
    return ivalue
    
# Arguments    
parser = argparse.ArgumentParser(description='Deleting folder')
parser.add_argument('-f', '--folder', type=str, help='folder id to delete', default='0BwcPr38tzpusaXNhcy13dnQ1elE')
parser.add_argument('-u', '--user', type=str, help='user that will move files', default='user')
parser.add_argument('-b', '--bottime', help='time that the bot will upload files', type=int_positive, default=1)
args = parser.parse_args()    

def usage():
	print('#############################################')
	print('Usage - python deleteFolder.py -f <folder_id> ')
	print('#############################################')
    
def deleteFolder(service, folder_id):
	try:
		dir_id = folder_id
		#file_id = "avoid deleting this file"

		#service.files().update(fileId=file_id, addParents="root", removeParents=dir_id).execute()
		service.files().delete(fileId=dir_id).execute()    
	except errors.HttpError, error:
		print 'An error occurred: %s' % error
		usage()
		sys.exit()
   
def main():
		
	# Passar por argumento o id do folder a apagar
	# use - python deleteFolder.py -f <folder_id>	
	# Funciona como bot ou user porque ao apagar a pasta apaga também os ficheiros mas todos ao mesmo tempo
	credentials = up.get_credentials()
	http = credentials.authorize(httplib2.Http())
	service = discovery.build('drive', 'v3', http=http)	

	deleteFolder(service, args.folder)
	print('Deleting folder succesfully!')
 
if __name__ == '__main__':
    main()

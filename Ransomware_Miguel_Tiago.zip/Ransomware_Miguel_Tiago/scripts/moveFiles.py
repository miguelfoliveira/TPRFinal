#!/usr/bin/python
import sys
import argparse

from apiclient import errors
from httplib2 import Http
from apiclient.discovery import build
from oauth2client import file, client, tools

from apiclient import discovery
from oauth2client.file import Storage

import utils_Upload as up
import httplib2
import time
import numpy as np

def int_positive(value):
    #ivalue = int(value)
    ivalue = float(value)
    if ivalue < 0:
        raise argparse.ArgumentTypeError("%s is an invalid positive int value" % value)
    return ivalue
    
# Arguments    
parser = argparse.ArgumentParser(description='Moving folder')
parser.add_argument('-s', '--sourcefolder', type=str, help='source folder id', default='0BwcPr38tzpusVjRWcFhvTzBiOTQ')
parser.add_argument('-d', '--destinationfolder', type=str, help='destination folder id', default='0BwcPr38tzpusMWR3aEJqQXU1dzQ')
parser.add_argument('-u', '--user', type=str, help='user that will move files', default='user')
parser.add_argument('-b', '--bottime', help='time that the bot will upload files', type=int_positive, default=1)
args = parser.parse_args() 

def usage():
	print('###############################################################################################################################')
	print('Usage - python moveFiles.py -s <source_folder_id> -d <destination_folder> -u <user/bot> -b <time to time the bot to move files>')
	print('###############################################################################################################################')

def printFilesFolder(service, service2, folder_id_source, folder_id_dest, user, time_bot):
  """Print files belonging to a folder.
  Args:
    service: Drive API service instance.
    folder_id: ID of the folder to print files from.
  """
  page_token = None
  while True:
    try:
      param = {}
      if page_token:
        param['pageToken'] = page_token
      children = service.children().list(folderId=folder_id_source, **param).execute()
      if len(children.get('items', [])) == 0:
		  print('The selected folder contains no files to move... select another folder!!')
		  print('Usage - python moveFiles.py -s <source_folder_id> -d <destination_folder_id>	')
		  sys.exit()
      for child in children.get('items', []):
		moveFiles(service2, str(child['id']), folder_id_dest, user, time_bot)
      page_token = children.get('nextPageToken')
      if not page_token:
        break
    except errors.HttpError, error:
      print 'An error occurred: %s' % error
      usage()
      sys.exit()


def moveFiles(service, file_id, folder_id_destination, user, time_bot):
	try:			 							 								
		file = service.files().get(fileId=file_id,
									 fields='parents').execute();
		previous_parents = ",".join(file.get('parents'))
		# Move the file to the new folder
		if user=='user':
			time.sleep(np.random.exponential(scale=10))	
		else:
			time.sleep(time_bot)	
		file = service.files().update(fileId=file_id,
										addParents=folder_id_destination,
										removeParents=previous_parents,
										fields='id, parents').execute()
		print('Move file "%s" to folder (%s)' % (file_id, folder_id_destination))
	except errors.HttpError, error:	
		print 'An error occurred: %s' % error
		usage()
		sys.exit()
    
def main():
	# usage - python moveFiles.py -s <source_folder_id> -d <destination_folder_id>	
	credentials = up.get_credentials()
	http = credentials.authorize(httplib2.Http())
	service = discovery.build('drive', 'v2', http=http)
	service2 = discovery.build('drive', 'v3', http=http)
	
	printFilesFolder(service, service2, args.sourcefolder, args.destinationfolder, args.user, args.bottime)
	print('Move files succesfully!') 
 
if __name__ == '__main__':
    main()

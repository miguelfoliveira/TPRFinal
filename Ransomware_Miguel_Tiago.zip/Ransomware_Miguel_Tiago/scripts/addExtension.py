#!/usr/bin/python
import sys
import argparse

from apiclient import errors
from httplib2 import Http
from apiclient.discovery import build
from oauth2client import file, client, tools

from apiclient import discovery
from oauth2client.file import Storage

import utils_Upload as up
import httplib2
import time
import numpy as np

def int_positive(value):
    #ivalue = int(value)
    ivalue = float(value)
    if ivalue < 0:
        raise argparse.ArgumentTypeError("%s is an invalid positive int value" % value)
    return ivalue

# Arguments    
parser = argparse.ArgumentParser(description='Moving folder')
parser.add_argument('-s', '--sourcefolder', type=str, help='source folder id', default='0BwcPr38tzpusMWR3aEJqQXU1dzQ')
parser.add_argument('-e', '--extension', type=str, help='extension to add to files', default='xyz')
parser.add_argument('-u', '--user', type=str, help='user that will move files', default='user')
parser.add_argument('-b', '--bottime', help='time that the bot will upload files', type=int_positive, default=1)
args = parser.parse_args() 

def usage():
	print('###################################################################')
	print('Usage - python addExtension.py -s <source_folder_id> -e <extension> -u <user/bot> -b <time to time the bot to move files>')
	print('###################################################################')
	

def printFilesFolder(service, folder_id_source, extension, user, time_bot):
  """Print files belonging to a folder.
  Args:
    service: Drive API service instance.
    folder_id: ID of the folder to print files from.
  """
  page_token = None
  while True:
    try:
      param = {}
      if page_token:
        param['pageToken'] = page_token
      children = service.children().list(folderId=folder_id_source, **param).execute()
      if len(children.get('items', [])) == 0:
		  print('The selected folder contains no files to rename... select another folder!!')
		  usage()
		  sys.exit()
      for child in children.get('items', []):
        addExtensionFile(service, str(child['id']), extension, user, time_bot)
      page_token = children.get('nextPageToken')
      if not page_token:
        break
    except errors.HttpError, error:
      print 'An error occurred: %s' % error
      usage()
      sys.exit()

                                    
def addExtensionFile(service, file_id, extension, user, time_bot):
	"""Add extension to a file.
	Args:
	service: Drive API service instance.
	file_id: ID of the file to rename.
	Returns:
	Updated file metadata if successful, None otherwise.
	"""
	try:
		file = service.files().get(fileId=file_id).execute()
		#print 'Title: %s' % file['title']
		file2 = {'title': file['title']+'.'+extension}
		
		if user=='user':
			time.sleep(np.random.exponential(scale=10))	
		else:
			time.sleep(time_bot)
		updated_file = service.files().patch(
			fileId=file_id,
			body=file2,
			fields='title').execute()
		
		print('Adding extension from file "%s" to "%s"' % (file['title'], file['title']+'.'+extension))
		return updated_file
	except errors.HttpError, error:
		print 'An error occurred: %s' % error
		usage()
		return None	      	                            
    
def main():
	# usage - python addExtension.py -s <source_folder_id> -e <extension> -u <user/bot> -b <time to time the bot to move files>
	credentials = up.get_credentials()
	http = credentials.authorize(httplib2.Http())
	service = discovery.build('drive', 'v2', http=http)
	
	printFilesFolder(service, args.sourcefolder, args.extension, args.user, args.bottime)
	print('Adding extension to files succesfully!') 
 
if __name__ == '__main__':
    main()
